# Approach and Assumptions

## Purpose
This project is a .NET 8 console application that demonstrates Retrieval Augmented Generation over local story text files. The system answers questions using retrieved story chunks as the only evidence. If the answer is not present in the retrieved context, it should refuse. Hence, it should avoid LLM hallucination. 

## What the program does
The program runs in two phases.

Phase 1 ingestion
It reads selected txt files from the `Stories` folder, chunks each file, generates embeddings for each chunk, and writes the results as json files under `VectorStore`.

Phase 2 question answering
It retrieves the most similar chunks from selected collections and sends a grounded prompt to the language model.

## Key parameters used
Chunking
MaxChunkTokenCount is `200`
OverlapPercentage is `10`

Retrieval
Per selected collection, retrieve up to `5` chunks
Across all selected collections, keep the overall top `5` chunks by score
Similarity threshold is `0.50`

Refusal sentence
The model is instructed to reply with this exact sentence when the answer is not in the context.
"I cannot find this information in the provided documents."

## Phase 1 ingestion details
File selection
The program lists all txt files under `Stories` and asks the user to select by number. Invalid input is rejected and the program asks the user to try again.

Per file storage
Each story file is stored in its own collection folder under `VectorStore`. The collection folder name is derived from the story file name without extension and then sanitized to be a valid folder name.

Chunking configuration
```csharp
var slicer = new Slicer(new SlicerOptions
{
    MaxChunkTokenCount = 200,
    OverlapPercentage = 10
});
```

Embedding and writing
Each chunk is embedded and stored via `AddChunkAsync` with metadata fields "Source", "Collection", and "ChunkIndex".

Rate limit mitigation
The program waits `500` milliseconds between chunk embedding calls.

Partial ingestion handling per collection
The program checks json file count inside the collection folder.
If the count is greater than `15`, ingestion for that story is skipped.
If the count is between `1` and `15`, the folder is treated as partial ingestion, the folder is deleted, then the story is ingested again.
If the count is `0`, the story is ingested.

## Phase 2 question answering details
Collection selection
The program lists collection folders under `VectorStore` and asks the user to select by number. Invalid input is rejected and the program asks the user to try again.

Retrieval and filtering
```csharp
var part = await store.GetChunksAsync(query: userQuestion, topN: 5);
merged.AddRange(part);

var retrieved = merged
    .OrderByDescending(x => x.Score)
    .Take(5)
    .ToList();

const double similarityThreshold = 0.50;
var topChunks = retrieved
    .Where(c => c.Score >= similarityThreshold)
    .OrderByDescending(c => c.Score)
    .ToList();
```

Grounded prompt behavior
The prompt tells the model to use only the retrieved context and to refuse with the exact refusal sentence when the answer is not found.

```csharp
string groundedPrompt = $"""
You are a helpful assistant. Answer the question based ONLY on the following context from the documents.
If the answer cannot be found in the context, say "I cannot find this information in the provided documents."
Do not make up information or use knowledge outside of the provided context.

CONTEXT:
{context}

QUESTION: {userQuestion}

ANSWER:
""";
```

## Assumptions
1. A valid Gemini API key is configured and external calls succeed at runtime.
2. The working directory is consistent across run environments. `Stories` and `VectorStore` use relative paths, so a different working directory can point to different physical folders.
3. Input story files are plain text and readable by `File.ReadAllText`.
4. Stored json files are not modified between runs unless the user intentionally deletes a collection folder.
5. Similarity scores are comparable across chunks within a run, so sorting by score and using the fixed threshold `0.50` is meaningful.

## Limitations
1. Strict grounding will refuse creative writing requests, because the requested text does not exist in the retrieved context.
2. Strict grounding can also refuse reasonable inferences when the text does not explicitly state the conclusion.
3. Fixed parameters may not be optimal for every question. For example, the threshold `0.50` may be too strict for some queries.
4. Keeping only the overall top `5` chunks may omit supporting evidence when a question needs multiple distant parts of a story.

## How to validate
1. Ask a question whose answer is explicitly stated in a story and confirm the answer is supported by retrieved chunks.
2. Ask a question that is not answered in any selected story and confirm the model returns the exact refusal sentence.
3. Ask a question that could be confused across two stories and confirm the retrieved context comes from the correct collection before trusting the answer.