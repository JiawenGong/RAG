﻿using SemanticSlicer;
using SemanticSlicer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAGProject.Cli
{
    public class Samples
    {
        public static async Task TestGenerateContent(LLMService llmService)
        {
            var gen_result = await llmService.GetResponse("Write a poem about AI in the style of Shakespeare");
            Console.WriteLine("Response:" + Environment.NewLine + gen_result);
        }

        public static async Task TestEmbedding(LLMService llmService)
        {
            var embed_result = await llmService.GetEmbeddings("Hello, world!");

            Console.WriteLine("Embedding Length:" + embed_result.Count);
        }

        public static async Task TestVectorStore(LLMService llmService)
        {
            var vectorStore = new FileVectorStore(new GeminiEmbeddingGenerator(llmService), GlobalSettings.VECTOR_STORE_LOCATION);

            await vectorStore.AddChunkAsync(chunkText: 
"""                           
    Enter DAVY
  DAVY. Here, sir.
  SHALLOW. Davy, Davy, Davy, Davy; let me see, Davy; let me see,
    Davy; let me see- yea, marry, William cook, bid him come hither.
    Sir John, you shall not be excus'd.
  DAVY. Marry, sir, thus: those precepts cannot be served; and,
    again, sir- shall we sow the headland with wheat?
  SHALLOW. With red wheat, Davy. But for William cook- are there no
    young pigeons?  
  DAVY. Yes, sir. Here is now the smith's note for shoeing and
    plough-irons.
  SHALLOW. Let it be cast, and paid. Sir John, you shall not be
    excused.
  DAVY. Now, sir, a new link to the bucket must needs be had; and,
    sir, do you mean to stop any of William's wages about the sack he
    lost the other day at Hinckley fair?
  SHALLOW. 'A shall answer it. Some pigeons, Davy, a couple of
    short-legg'd hens, a joint of mutton, and any pretty little tiny
    kickshaws, tell William cook.
  DAVY. Doth the man of war stay all night, sir?
  SHALLOW. Yea, Davy; I will use him well. A friend i' th' court is
    better than a penny in purse. Use his men well, Davy; for they
    are arrant knaves and will backbite.
  DAVY. No worse than they are backbitten, sir; for they have
    marvellous foul linen.
  SHALLOW. Well conceited, Davy- about thy business, Davy.
  DAVY. I beseech you, sir, to countenance William Visor of Woncot
    against Clement Perkes o' th' hill.
  SHALLOW. There, is many complaints, Davy, against that Visor. That  
    Visor is an arrant knave, on my knowledge.
  DAVY. I grant your worship that he is a knave, sir; but yet God
    forbid, sir, but a knave should have some countenance at his
    friend's request. An honest man, sir, is able to speak for
    himself, when a knave is not. I have serv'd your worship truly,
    sir, this eight years; an I cannot once or twice in a quarter
    bear out a knave against an honest man, I have but a very little
    credit with your worship. The knave is mine honest friend, sir;
    therefore, I beseech you, let him be countenanc'd.
  SHALLOW. Go to; I say he shall have no wrong. Look about,
  DAVY.  [Exit DAVY]  Where are you, Sir John? Come, come, come, off
    with your boots. Give me your hand, Master Bardolph.
  BARDOLPH. I am glad to see your worship.
  SHALLOW. I thank thee with all my heart, kind Master Bardolph.
    [To the PAGE]  And welcome, my tall fellow. Come, Sir John.
  FALSTAFF. I'll follow you, good Master Robert Shallow.
    [Exit SHALLOW]  Bardolph, look to our horses.  [Exeunt BARDOLPH
    and PAGE]  If I were sawed into quantities, I should make four
    dozen of such bearded hermits' staves as Master Shallow. It is a
    wonderful thing to see the semblable coherence of his men's  
    spirits and his. They, by observing of him, do bear themselves
    like foolish justices: he, by conversing with them, is turned
    into a justice-like serving-man. Their spirits are so married in
    conjunction with the participation of society that they flock
    together in consent, like so many wild geese. If I had a suit to
    Master Shallow, I would humour his men with the imputation of
    being near their master; if to his men, I would curry with Master
    Shallow that no man could better command his servants. It is
    certain that either wise bearing or ignorant carriage is caught,
    as men take diseases, one of another; therefore let men take heed
    of their company. I will devise matter enough out of this Shallow
    to keep Prince Harry in continual laughter the wearing out of six
    fashions, which is four terms, or two actions; and 'a shall laugh
    without intervallums. O, it is much that a lie with a slight
    oath, and a jest with a sad brow will do with a fellow that never
    had the ache in his shoulders! O, you shall see him laugh till
    his face be like a wet cloak ill laid up!
  SHALLOW.  [Within]  Sir John!
  FALSTAFF. I come, Master Shallow; I come, Master Shallow.
 Exit




SCENE II.
Westminster. The palace

Enter, severally, WARWICK, and the LORD CHIEF JUSTICE

  WARWICK. How now, my Lord Chief Justice; whither away?
  CHIEF JUSTICE. How doth the King?
  WARWICK. Exceeding well; his cares are now all ended.
  CHIEF JUSTICE. I hope, not dead.
  WARWICK. He's walk'd the way of nature;
    And to our purposes he lives no more.
  CHIEF JUSTICE. I would his Majesty had call'd me with him.
    The service that I truly did his life
    Hath left me open to all injuries.
  WARWICK. Indeed, I think the young king loves you not.
  CHIEF JUSTICE. I know he doth not, and do arm myself
    To welcome the condition of the time,
    Which cannot look more hideously upon me
    Than I have drawn it in my fantasy.

              Enter LANCASTER, CLARENCE, GLOUCESTER,  
                     WESTMORELAND, and others

  WARWICK. Here comes the heavy issue of dead Harry.
    O that the living Harry had the temper
    Of he, the worst of these three gentlemen!
    How many nobles then should hold their places
    That must strike sail to spirits of vile sort!
  CHIEF JUSTICE. O God, I fear all will be overturn'd.
  PRINCE JOHN. Good morrow, cousin Warwick, good morrow.
  GLOUCESTER & CLARENCE. Good morrow, cousin.
  PRINCE JOHN. We meet like men that had forgot to speak.
  WARWICK. We do remember; but our argument
    Is all too heavy to admit much talk.
  PRINCE JOHN. Well, peace be with him that hath made us heavy!
  CHIEF JUSTICE. Peace be with us, lest we be heavier!
  PRINCE HUMPHREY. O, good my lord, you have lost a friend indeed;
    And I dare swear you borrow not that face
    Of seeming sorrow- it is sure your own.
  PRINCE JOHN. Though no man be assur'd what grace to find,
    You stand in coldest expectation.  
    I am the sorrier; would 'twere otherwise.
  CLARENCE. Well, you must now speak Sir John Falstaff fair;
    Which swims against your stream of quality.
  CHIEF JUSTICE. Sweet Princes, what I did, I did in honour,
    Led by th' impartial conduct of my soul;
    And never shall you see that I will beg
    A ragged and forestall'd remission.
    If truth and upright innocency fail me,
    I'll to the King my master that is dead,
    And tell him who hath sent me after him.
  WARWICK. Here comes the Prince.

            Enter KING HENRY THE FIFTH, attended

  CHIEF JUSTICE. Good morrow, and God save your Majesty!
  KING. This new and gorgeous garment, majesty,
    Sits not so easy on me as you think.
    Brothers, you mix your sadness with some fear.
    This is the English, not the Turkish court;
    Not Amurath an Amurath succeeds,  
    But Harry Harry. Yet be sad, good brothers,
    For, by my faith, it very well becomes you.
    Sorrow so royally in you appears
    That I will deeply put the fashion on,
    And wear it in my heart. Why, then, be sad;
    But entertain no more of it, good brothers,
    Than a joint burden laid upon us all.
    For me, by heaven, I bid you be assur'd,
    I'll be your father and your brother too;
    Let me but bear your love, I'll bear your cares.
    Yet weep that Harry's dead, and so will I;
    But Harry lives that shall convert those tears
    By number into hours of happiness.
  BROTHERS. We hope no otherwise from your Majesty.
  KING. You all look strangely on me; and you most.
    You are, I think, assur'd I love you not.
  CHIEF JUSTICE. I am assur'd, if I be measur'd rightly,
    Your Majesty hath no just cause to hate me.
  KING. No?
    How might a prince of my great hopes forget  
    So great indignities you laid upon me?
    What, rate, rebuke, and roughly send to prison,
    Th' immediate heir of England! Was this easy?
    May this be wash'd in Lethe and forgotten?
  CHIEF JUSTICE. I then did use the person of your father;
    The image of his power lay then in me;
    And in th' administration of his law,
    Whiles I was busy for the commonwealth,
    Your Highness pleased to forget my place,
    The majesty and power of law and justice,
    The image of the King whom I presented,
    And struck me in my very seat of judgment;
    Whereon, as an offender to your father,
    I gave bold way to my authority
    And did commit you. If the deed were ill,
    Be you contented, wearing now the garland,
    To have a son set your decrees at nought,
    To pluck down justice from your awful bench,
    To trip the course of law, and blunt the sword
    That guards the peace and safety of your person;  
    Nay, more, to spurn at your most royal image,
    And mock your workings in a second body.
    Question your royal thoughts, make the case yours;
    Be now the father, and propose a son;
    Hear your own dignity so much profan'd,
    See your most dreadful laws so loosely slighted,
    Behold yourself so by a son disdain'd;
    And then imagine me taking your part
    And, in your power, soft silencing your son.
    After this cold considerance, sentence me;
    And, as you are a king, speak in your state
    What I have done that misbecame my place,
    My person, or my liege's sovereignty.
  KING. You are right, Justice, and you weigh this well;
    Therefore still bear the balance and the sword;
    And I do wish your honours may increase
    Till you do live to see a son of mine
    Offend you, and obey you, as I did.
    So shall I live to speak my father's words:
    'Happy am I that have a man so bold  
    That dares do justice on my proper son;
    And not less happy, having such a son
    That would deliver up his greatness so
    Into the hands of justice.' You did commit me;
    For which I do commit into your hand
    Th' unstained sword that you have us'd to bear;
    With this remembrance- that you use the same
    With the like bold, just, and impartial spirit
    As you have done 'gainst me. There is my hand.
    You shall be as a father to my youth;
    My voice shall sound as you do prompt mine ear;
    And I will stoop and humble my intents
    To your well-practis'd wise directions.
    And, Princes all, believe me, I beseech you,
    My father is gone wild into his grave,
    For in his tomb lie my affections;
    And with his spirits sadly I survive,
    To mock the expectation of the world,
    To frustrate prophecies, and to raze out
    Rotten opinion, who hath writ me down  
    After my seeming. The tide of blood in me
    Hath proudly flow'd in vanity till now.
    Now doth it turn and ebb back to the sea,
    Where it shall mingle with the state of floods,
    And flow henceforth in formal majesty.
    Now call we our high court of parliament;
    And let us choose such limbs of noble counsel,
    That the great body of our state may go
    In equal rank with the best govern'd nation;
    That war, or peace, or both at once, may be
    As things acquainted and familiar to us;
    In which you, father, shall have foremost hand.
    Our coronation done, we will accite,
    As I before rememb'red, all our state;
    And- God consigning to my good intents-
    No prince nor peer shall have just cause to say,
        God shorten Harry's happy life one day.               Exeunt 
""",
                metadata: new Dictionary<string, string>
                {
            { "Source", "SampleDocument.txt" },
            { "ChunkIndex", "1" }
                });

            var matchResult = await vectorStore.GetChunksAsync(query: "The father killed his son with a sword.", topN: 5);
                Console.WriteLine($"Matches returned: {matchResult.Count}");

            for (int i = 0; i < matchResult.Count; i++)
            {
                var r = matchResult[i];

                r.Metadata.TryGetValue("Source", out var source);
                r.Metadata.TryGetValue("ChunkIndex", out var chunkIndex);

                source ??= "Unknown";
                chunkIndex ??= "Unknown";

                string preview = r.Text.Replace("\r", " ").Replace("\n", " ");
                if (preview.Length > 160) preview = preview.Substring(0, 160) + "...";

                Console.WriteLine($"Result {i + 1}");
                Console.WriteLine($"Score: {r.Score:F3}");
                Console.WriteLine($"Source: {source}");
                Console.WriteLine($"ChunkIndex: {chunkIndex}");
                Console.WriteLine(preview);
                Console.WriteLine();
            }
        }

        public static List<DocumentChunk> ChunkDocument(string dataSourceLocation)
        {
            string text = File.ReadAllText(dataSourceLocation);
            var slicer = new Slicer();
            var chunks = slicer.GetDocumentChunks(text);
            Console.WriteLine($"Total Chunks Created: {chunks.Count}");
            return chunks;
        }

    }
}
