﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RAGProject.Cli
{
    internal class GlobalSettings
    {
        //change the Datasource to the full path of file in the Stories folder 
        public static readonly string ShakespeareWorks_DataSourceLocation = Path.Combine("Stories", "ShakespeareWorks.txt");
        //change the Datasource to the full path of file in the Stories folder 
        public static readonly string AesopFables_DataSourceLocation = Path.Combine("Stories", "AesopFables.txt");
        //change the API key to your own key
        public const string API_KEY = "Your API Key";
        //change the vector store location to your desired location where you want to store the files with chunk and vector embeddings
        public static readonly string VECTOR_STORE_LOCATION = Path.Combine("..", "VectorStore");

        //Keep these the same
        public const string LLM_MODEL = "gemini-2.5-flash";
        public const string EMBED_MODEL = "gemini-embedding-001";
    }
}
