﻿using RAGProject.Cli;
using SemanticSlicer;
using SemanticSlicer.Models;
using System.Linq;


try
{
    var llmService = new LLMService();
    var embeddingGenerator = new GeminiEmbeddingGenerator(llmService);
    Directory.CreateDirectory(GlobalSettings.VECTOR_STORE_LOCATION);

    // Parse user selection input into valid 1 based indices
    List<int> ParseSelection(string input, int maxIndex)
    {
        input = (input ?? "").Trim();
        if (string.IsNullOrWhiteSpace(input)) return Enumerable.Range(1, maxIndex).ToList();
        if (string.Equals(input, "all", StringComparison.OrdinalIgnoreCase))
            return Enumerable.Range(1, maxIndex).ToList();

        var parts = input.Split(new[] { ',', ' ', ';' }, StringSplitOptions.RemoveEmptyEntries);
        var nums = new List<int>();
        foreach (var p in parts)
        {
            if (int.TryParse(p, out var k) && k >= 1 && k <= maxIndex) nums.Add(k);
        }
        return nums.Distinct().ToList();
    }

    // Convert a file name into a safe folder name for a collection
    string SanitizeName(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var chars = name.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray();
        var cleaned = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(cleaned) ? "Default" : cleaned;
    }

    Console.WriteLine("=== Phase 1: Document Ingestion ===");
    Console.WriteLine();

    // Discover available story files under the Stories folder
    var storiesDir = "Stories";
    var storyFiles = Directory.EnumerateFiles(storiesDir, "*.txt", SearchOption.TopDirectoryOnly)
        .OrderBy(p => p)
        .ToList();
    if (storyFiles.Count == 0)
    {
        Console.WriteLine("No txt files found in Stories folder.");
        return;
    }
    List<int> selectedNums;

    // Keep prompting until the user selects at least one valid file
    do
    {
        Console.WriteLine("Select files to ingest by number, use commas for multiple.");
        for (int i = 0; i < storyFiles.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {Path.GetFileName(storyFiles[i])}");
        }
        Console.Write("Selection: ");
        string selectionInput = Console.ReadLine() ?? "";
        selectedNums = ParseSelection(selectionInput, storyFiles.Count);
        if (selectedNums.Count == 0)
        {
            Console.WriteLine("Invalid input. Try again.");
            Console.WriteLine();
            continue;
        }
        else
        {
            break;
        }
    } while (true);

    var selectedFiles = selectedNums.Select(n => storyFiles[n - 1]).ToList();

    // Configure chunking size and overlap
    var slicer = new Slicer(new SlicerOptions
    {
        MaxChunkTokenCount = 200,
        OverlapPercentage = 10
    });

    // Ingest each selected story into its own collection folder
    foreach (var dataSource in selectedFiles)
    {
        var collection = SanitizeName(Path.GetFileNameWithoutExtension(dataSource));
        var storeDir = Path.Combine(GlobalSettings.VECTOR_STORE_LOCATION, collection);
        int existingCount = Directory.Exists(storeDir)
    ? Directory.EnumerateFiles(storeDir, "*.json", SearchOption.TopDirectoryOnly).Count()
    : 0;

    // Count existing json chunks to decide whether to skip or rebuild this collection
        if (existingCount > 15)
        {
            Console.WriteLine($"Skip ingestion for {Path.GetFileName(dataSource)} because it already has {existingCount} chunks.");
            Console.WriteLine();
            continue;
        }

        if (existingCount > 0)
        {
            Console.WriteLine($"Detected partial ingestion for {Path.GetFileName(dataSource)}. Re ingesting this file.");
            Directory.Delete(storeDir, true);
        }

        Directory.CreateDirectory(storeDir);

        var vectorStore = new FileVectorStore(embeddingGenerator, storeDir);

        Console.WriteLine($"Reading document from: {dataSource}");

        // Load the full story text into memory
        string documentText = File.ReadAllText(dataSource);
        Console.WriteLine($"Document loaded: {documentText.Length} characters");
        // Split the document into semantic chunks
        var chunks = slicer.GetDocumentChunks(documentText);
        Console.WriteLine($"Document chunked into {chunks.Count} pieces");

        int maxChunks = chunks.Count;
        Console.WriteLine($"Processing all {maxChunks} chunks for embedding.");
        Console.WriteLine();

        for (int i = 0; i < maxChunks; i++)
        {
            var chunk = chunks[i];
            Console.WriteLine($"Embedding chunk {i + 1}/{maxChunks}...");

            // Embed and persist each chunk with traceable metadata
            await vectorStore.AddChunkAsync(
                chunkText: chunk.Content,
                metadata: new Dictionary<string, string>
                {
                { "Source", Path.GetFileName(dataSource) },
                { "Collection", collection },
                { "ChunkIndex", i.ToString() }
                });
            
            await Task.Delay(500); // Short delay to reduce rate limit errors
        }
    }




    Console.WriteLine();
    Console.WriteLine("Ingestion complete! Documents have been embedded and stored.");
    Console.WriteLine();

    // ==========================================
    // Phase 2: Inquiry Loop
    // ==========================================
    Console.WriteLine("=== Phase 2: Question & Answer ===");
    Console.WriteLine("Ask questions about the documents. Type 'exit' to quit.");
    Console.WriteLine();

    while (true)
    {
        var collections = Directory.EnumerateDirectories(GlobalSettings.VECTOR_STORE_LOCATION, "*", SearchOption.TopDirectoryOnly)
    .Select(Path.GetFileName)
    .Where(s => !string.IsNullOrWhiteSpace(s))
    .OrderBy(s => s)
    .ToList();

        if (collections.Count == 0)
        {
            Console.WriteLine("No ingested collections found. Run ingestion first.");
            Console.WriteLine();
            continue;
        }
    // List ingested collections so the user can choose which stories to search
        Console.WriteLine("Select which documents to answer from by number, use commas for multiple. ");
        for (int i = 0; i < collections.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {collections[i]}");
        }
        Console.Write("Selection: ");
        string answerSelection = Console.ReadLine() ?? "";
        var selectedNums2 = ParseSelection(answerSelection, collections.Count);
        if (selectedNums2.Count == 0)
        {
            Console.WriteLine("Invalid Input, Try again.");
            Console.WriteLine();
            continue;
        }
        var selectedCollections = selectedNums2.Select(n => collections[n - 1]).ToList();

        Console.Write("Ask questions about the documents. Type 'exit' to quit:");
        string? userQuestion = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(userQuestion))
        {
            Console.WriteLine("Please enter a valid question.");
            continue;
        }

        if (userQuestion.Trim().ToLower() == "exit")
        {
            Console.WriteLine("Goodbye!");
            break;
        }

        Console.WriteLine();
        Console.WriteLine("Searching for relevant content...");

        // Retrieve top 5 similar chunks
        var merged = new List<ChunkResult>();

        foreach (var c in selectedCollections)
        {
            var dir = Path.Combine(GlobalSettings.VECTOR_STORE_LOCATION, c);
            if (!Directory.Exists(dir)) continue;

            var store = new FileVectorStore(embeddingGenerator, dir);
            var part = await store.GetChunksAsync(query: userQuestion, topN: 5);
            merged.AddRange(part);
        }

        var retrieved = merged
            .OrderByDescending(x => x.Score)
            .Take(5)
            .ToList();

        // Drop low similarity matches to enforce grounded answers
        const double similarityThreshold = 0.50;
        var topChunks = retrieved.Where(chunk => chunk.Score >= similarityThreshold).OrderByDescending(chunk => chunk.Score).ToList();

        if (topChunks.Count == 0)
        {
            Console.WriteLine("No relevant documents found. Please try a different question.");
            Console.WriteLine();
            continue;
        }

        Console.WriteLine($"Found {topChunks.Count} relevant chunks. Generating answer...");
        Console.WriteLine();

        // Build grounded prompt with retrieved context
        string context = string.Join("\n\n---\n\n", topChunks.Select(c => c.Text));

        string groundedPrompt = $"""
You are a helpful assistant. Answer the question based ONLY on the following context from the documents.
If the answer cannot be found in the context, say "I cannot find this information in the provided documents."
Do not make up information or use knowledge outside of the provided context.

CONTEXT:
{context}

QUESTION: {userQuestion}

ANSWER:
""";

        // Get LLM response
        string answer = await llmService.GetResponse(groundedPrompt);

        Console.WriteLine("Answer:");
        Console.WriteLine("----------------------------------------");
        Console.WriteLine(answer);
        Console.WriteLine("----------------------------------------");
        Console.WriteLine();
    }
}
catch (Exception ex) // Catch and print unexpected runtime errors for debugging
{
    Console.WriteLine($"Error: {ex.Message}");
    Console.WriteLine($"Stack Trace: {ex.StackTrace}");
    if (ex.InnerException != null)
    {
        Console.WriteLine($"Inner Error: {ex.InnerException.Message}");
    }
}

Console.WriteLine("Press any key to exit...");
Console.ReadKey();
