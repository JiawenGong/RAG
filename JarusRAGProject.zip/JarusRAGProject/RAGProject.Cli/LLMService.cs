﻿using Google.GenAI;
using Google.GenAI.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAGProject.Cli
{
    public class LLMService
    {
        
        public async Task<string> GetResponse(string request)
        {
            var client = new Client(apiKey: GlobalSettings.API_KEY);
            var response = await client.Models.GenerateContentAsync(
              model: GlobalSettings.LLM_MODEL, contents: request
            );
            var resultText = response?.Candidates?.FirstOrDefault()?.Content?.Parts?.FirstOrDefault()?.Text ?? "";
            return resultText;
        }

        public async Task<List<double>> GetEmbeddings(string text)
        {
            var client = new Client(apiKey: GlobalSettings.API_KEY);
            var response = await client.Models.EmbedContentAsync(
              model: GlobalSettings.EMBED_MODEL, contents: text);
            var result = response.Embeddings?.FirstOrDefault();
            return result.Values;
        }

    }
}
