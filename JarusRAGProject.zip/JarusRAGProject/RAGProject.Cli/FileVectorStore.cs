﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace RAGProject.Cli;


public class FileVectorStore
{
    private readonly IEmbeddingGenerator _embeddingGenerator;
    private readonly string _storageDirectory;

    public FileVectorStore(
        IEmbeddingGenerator embeddingGenerator,
        string storageDirectory)
    {
        _embeddingGenerator = embeddingGenerator;
        _storageDirectory = storageDirectory;

        Directory.CreateDirectory(_storageDirectory);
    }

    public async Task AddChunkAsync(
        string chunkText,
        Dictionary<string, string> metadata)
    {
        var embedding = await _embeddingGenerator.GenerateEmbeddingAsync(chunkText);

        var chunk = new StoredChunk
        {
            Text = chunkText,
            Embedding = embedding,
            Metadata = metadata
        };

        var path = Path.Combine(_storageDirectory, $"{chunk.Id}.json");

        var json = JsonSerializer.Serialize(
            chunk,
            new JsonSerializerOptions { WriteIndented = true });

        await File.WriteAllTextAsync(path, json);
    }

    public async Task<IReadOnlyList<ChunkResult>> GetChunksAsync(
        string query,
        int topN = 5,
        Func<Dictionary<string, string>, bool>? metadataFilter = null)
    {
        var queryEmbedding =
            await _embeddingGenerator.GenerateEmbeddingAsync(query);

        var results = new List<ChunkResult>();

        foreach (var file in Directory.EnumerateFiles(_storageDirectory, "*.json"))
        {
            var json = await File.ReadAllTextAsync(file);
            var chunk = JsonSerializer.Deserialize<StoredChunk>(json)!;

            if (metadataFilter != null &&
                !metadataFilter(chunk.Metadata))
                continue;

            var score = VectorMath.CosineSimilarity(
                queryEmbedding,
                chunk.Embedding);

            results.Add(new ChunkResult
            {
                ChunkId = chunk.Id,
                Text = chunk.Text,
                Metadata = chunk.Metadata,
                Score = score
            });
        }

        return results
            .OrderByDescending(r => r.Score)
            .Take(topN)
            .ToList();
    }
}

internal static class VectorMath
{
    public static double CosineSimilarity(List<double> a, List<double> b)
    {
        if (a.Count != b.Count)
            throw new InvalidOperationException("Embedding dimension mismatch");

        double dot = 0f;
        double magA = 0f;
        double magB = 0f;

        for (int i = 0; i < a.Count; i++)
        {
            dot += a[i] * b[i];
            magA += a[i] * a[i];
            magB += b[i] * b[i];
        }

        return dot / ((float)Math.Sqrt(magA) * (float)Math.Sqrt(magB));
    }
}

public interface IEmbeddingGenerator
{
    Task<List<double>> GenerateEmbeddingAsync(string text);
}

internal class StoredChunk
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Text { get; set; } = string.Empty;
    public List<double> Embedding { get; set; } = new List<double>();
    public Dictionary<string, string> Metadata { get; set; } = new();
}

public class ChunkResult
{
    public string ChunkId { get; init; } = string.Empty;
    public string Text { get; init; } = string.Empty;
    public Dictionary<string, string> Metadata { get; init; } = new();
    public double Score { get; init; }
}

public class GeminiEmbeddingGenerator : IEmbeddingGenerator
{
    LLMService _llmService;
    public GeminiEmbeddingGenerator(LLMService llmService)
    {
        _llmService = llmService;
    }

    public async Task<List<double>> GenerateEmbeddingAsync(string text)
    {
        var embeddings = await _llmService.GetEmbeddings(text);

        return embeddings;
    }
}